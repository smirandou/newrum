pub mod rumload;
pub mod execute;
pub mod instructions;
pub mod fields;
pub mod opcode_matching;

#[cfg(test)]
mod tests {
    use crate::execute::{execute_rum, RUM};
    use crate::fields::{get, RA, RB, RC};
    use crate::opcode_matching::input;

    // #[test]
    // Since this "essentially" a interpreter for a small programming language, it makes sense to
    // primarily perform integration tests.
    //
    // This makes sense because many bugs in programming languages occur due to the combination of modules working together.
    // It wouldn't make sense to spend unnecessary time writing unit tests that may not work in the grand scheme of things.
    // and in our case, testing the rum binaries were very helpful by disassembling parts of the instructions and making sure the
    // program works as a whole.



}

