use std::env;
use lib::rumload;
use lib::execute::execute_rum;

fn main() {
    //holds the input file
    let input = env::args().nth(1);
    //loads the instructions from the input file
    let instructions = rumload::load(input.as_deref());
    //executes program
    execute_rum(instructions);
}
