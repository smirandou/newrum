use crate::execute::RUM;
use crate::fields::{get, OP, Opcode, RA, RB, RC, RL};
use crate::opcode_matching::{
    add, cmov, div, input, load, load_program, load_value, map_seg, mul, nand, output, store,
    unmap_seg,
};

/// Runs the instructions at memory segment zero
/// Will continue running until program halts, or runs out of instructions to run.
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::instructions::run_instructions;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// run_instructions(&mut mock_rum);
/// ```
pub fn run_instructions(rum: &mut RUM) {
    loop {
        instruction_opcode(rum, rum.mem_seg[0][rum.instruction_counter]);
    }
}

/// Runs the specific instruction given to the function
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'instruction' - a u32 instruction
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::instructions::instruction_opcode;
///
/// let mock_instruction = 123_u32;
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// instruction_opcode(&mut mock_rum, mock_instruction);
/// ```
pub fn instruction_opcode(rum: &mut RUM, instruction: u32) {
    let a = get(&RA, instruction) as usize;
    let b = get(&RB, instruction) as usize;
    let c = get(&RC, instruction) as usize;

    match get(&OP, instruction) {
        o if o == Opcode::CMov as u32 => {
            cmov(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Load as u32 => {
            load(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Store as u32 => {
            store(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Add as u32 => {
            add(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Mul as u32 => {
            mul(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Div as u32 => {
            div(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::NAND as u32 => {
            nand(rum, a, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::HALT as u32 => {
            std::process::exit(0);
        }
        o if o == Opcode::MapSeg as u32 => {
            map_seg(rum, b, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::UMapSeg as u32 => {
            unmap_seg(rum, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::Out as u32 => {
            output(rum, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::In as u32 => {
            input(rum, c);
            rum.instruction_counter += 1;
        }
        o if o == Opcode::LP as u32 => {
            load_program(rum, b, c);
        }
        o if o == Opcode::LV as u32 => {
            load_value(rum, instruction, get(&RL, instruction) as usize);
            rum.instruction_counter += 1;
        }
        _ => panic!(),
    }
}
