pub struct Field {
    pub width: u32,
    pub lsb: u32,
}

pub static RA: Field = Field {width: 3, lsb: 6};
pub static RB: Field = Field {width: 3, lsb: 3};
pub static RC: Field = Field {width: 3, lsb: 0};
pub static RL: Field = Field {width: 3, lsb: 25};
pub static VL: Field = Field {width: 25, lsb: 0};
pub static OP: Field = Field {width: 4, lsb: 28};

fn mask(bits: u32) -> u32 { (1 << bits) - 1 }

pub fn get(field: &Field, instruction: u32) -> u32 {
    (instruction >> field.lsb) & ((1 << field.width) - 1)
}
pub fn op(instruction: u32) -> u32 {
    (instruction >> OP.lsb) & mask(OP.width)
}

pub enum Opcode {
    CMov, Load, Store, Add, Mul, Div, NAND, HALT, MapSeg, UMapSeg, Out, In, LP, LV
}
