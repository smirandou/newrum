use crate::instructions::run_instructions;

/// Representation of the Universal Machine's components and machine state
pub struct RUM {
    pub mem_seg: Vec<Vec<u32>>,
    pub furthest_mapped_segment: u32,
    pub registers: [u32; 8],
    pub open_seg: Vec<u32>,
    pub instruction_counter: usize
}

impl RUM {
    /// Returns a RUM representation holding instructions at the first index of
    /// mem_seg (Vec<Vec<u32>>).
    ///
    /// # Arguments
    ///
    /// * 'instructions' - vector of u32 instructions
    ///
    /// # Examples
    ///
    /// ```rust
    /// use lib::execute::RUM;
    ///
    /// let mock_rum = RUM::new(vec![u32::MAX]);
    ///
    /// assert_eq!(mock_rum.mem_seg[0][0] == u32::MAX);
    /// ```
    pub fn new(instructions: Vec<u32>) -> Self {
        RUM {
            mem_seg: vec![instructions],
            furthest_mapped_segment: 1,
            registers: [0;8],
            open_seg: Vec::new(),
            instruction_counter: 0,
        }
    }
}

/// Creates a mutable RUM object with instructions being loaded into memory segment 0
/// Calls a function that will run the instructions given
/// # Arguments
///
/// * 'instructions' - vector of u32 instructions
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::instructions::run_instructions;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// run_instructions(&mut mock_rum);
/// ```
pub fn execute_rum(instructions: Vec<u32>) {
    let mut rum = RUM::new(instructions);
    run_instructions(&mut rum);
}
