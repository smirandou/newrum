use crate::execute::RUM;
use std::io::{Read, stdin};

/// Assigns register B to register A
/// ONLY when register C's value doesn't equal zero
///
/// # Arguments
///
/// * `rum` - mutable reference to a rum object
/// * `a` - register a's identifier
/// * `b` - register b's identifier
/// * `c` - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::cmov;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// cmov(rum, a, b, c);
/// ```
pub fn cmov(rum: &mut RUM, a: usize, b: usize, c:usize) {
    if rum.registers[c] != 0 {
        rum.registers[a] = rum.registers[b];
    }
}

/// Loads a memory segment indexed by 'b' 'c' into register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::load;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// load(rum, a, b, c);
/// ```
pub fn load(rum: &mut RUM, a: usize, b: usize, c:usize) {
    if rum.registers[b] > rum.furthest_mapped_segment {
        panic!("unmapped segment");
    }
    rum.registers[a] = rum.mem_seg[rum.registers[b] as usize][rum.registers[c] as usize];
}

/// Stores the value at register indexed by 'c' into memory segment indexed by 'a' 'b'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::store;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// store(rum, a, b, c);
/// ```
pub fn store(rum: &mut RUM, a: usize, b: usize, c:usize) {
    rum.mem_seg[rum.registers[a] as usize][rum.registers[b] as usize] = rum.registers[c];
}

/// Adds the contents of registers indexed by 'b' and 'c' together and assigns it into
/// the register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::add;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// add(rum, a, b, c);
/// ```
pub fn add(rum: &mut RUM, a: usize, b: usize, c:usize) {
    rum.registers[a] = ((rum.registers[b] as u64 + rum.registers[c] as u64) % (1_u64 << 32)) as u32;
}

/// Multiplies the contents of registers indexed by 'b' and 'c' together and assigns it into
/// the register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::mul;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// mul(rum, a, b, c);
/// ```
pub fn mul(rum: &mut RUM, a: usize, b: usize, c:usize) {
    rum.registers[a] = ((rum.registers[b] as u64 * rum.registers[c] as u64) % (1_u64 << 32)) as u32;
}

/// Divides the contents of registers indexed by 'b' and 'c' together and assigns it into
/// the register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::div;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// div(rum, a, b, c);
/// ```
pub fn div(rum: &mut RUM, a: usize, b: usize, c:usize) {
    if rum.registers[c] == 0 {
        panic!();
    }
    rum.registers[a] = rum.registers[b] / rum.registers[c];
}

/// Nands the contents of registers indexed by 'b' and 'c' together and assigns it into
/// the register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'a' - register a's identifier
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RA, RB, RC};
/// use lib::opcode_matching::nand;
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let a = get(&RA, instruction) as usize;
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// nand(rum, a, b, c);
/// ```
pub fn nand(rum: &mut RUM, a: usize, b: usize, c:usize) {
    rum.registers[a] = !(rum.registers[b] & rum.registers[c]);
}

/// Maps a new segment (initialized to 0) to either a previously unmapped segment identifier, or
/// creates a new identifier and maps the new segment there
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RB, RC};
/// use lib::opcode_matching::{map_seg};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// map_seg(rum, b, c);
/// ```
pub fn map_seg(rum: &mut RUM, b:usize, c:usize) {
    let len = rum.registers[c] as usize;
    let new_seg = vec![0; len as usize];

    if !rum.open_seg.is_empty() {
        let open_seg = rum.open_seg.pop().unwrap();
        rum.registers[b] = open_seg;
        rum.mem_seg[open_seg  as usize] = new_seg;
    } else {
        rum.mem_seg.push(new_seg);
        rum.furthest_mapped_segment = (rum.mem_seg.len() - 1) as u32;
        rum.registers[b] = rum.furthest_mapped_segment;
    }
}

/// Unmaps segment at register indexed 'c'
/// Identifier will be stored away for later use
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RB, RC};
/// use lib::opcode_matching::{unmap_seg};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// unmap_seg(rum, c);
/// ```
pub fn unmap_seg(rum: &mut RUM, c:usize)
{
    if rum.registers[c] == 0 {
        panic!("Cannot unmap memory segment 0");
    }
    rum.open_seg.push(rum.registers[c]);
    rum.mem_seg[rum.registers[c] as usize].clear();
}

/// Outputs value at register indexed 'c'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RB, RC};
/// use lib::opcode_matching::{output};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// output(rum, c);
/// ```
pub fn output(rum: &mut RUM, c:usize) {
    if rum.registers[c] > 255 {
        panic!("Number bad");
    }
    print!("{}", char::from_u32(rum.registers[c]).unwrap());
}

/// Inputs value at register indexed 'c'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RB, RC};
/// use lib::opcode_matching::{input};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// input(rum, c);
/// ```
pub fn input(rum: &mut RUM, c:usize) {
    let mut buffer: [u8;1] = [0];

    let character = stdin().read(&mut buffer);

    rum.registers[c] = match character {
        Ok(1) => buffer[0] as u32,
        Ok(0) => u32::MAX,
        _ => panic!()
    };
}

/// Loads a new program into memory segment '0'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'b' - register b's identifier
/// * 'c' - register c's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RB, RC};
/// use lib::opcode_matching::{load_program};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let b = get(&RB, instruction) as usize;
/// let c = get(&RC, instruction) as usize;
///
/// load_program(rum, b, c);
/// ```
pub fn load_program(rum: &mut RUM, b: usize, c:usize) {
    if rum.registers[b] != 0 {
        rum.mem_seg[0] = rum.mem_seg[rum.registers[b] as usize].clone();
    }
    rum.instruction_counter = rum.registers[c] as usize;
}

/// Loads the first 25 bits of an instruction into register indexed by 'a'
///
/// # Arguments
///
/// * 'rum' - mutable reference to a rum object
/// * 'instruction' - u32 instruction
/// * 'a' - register a's identifier
///
/// # Examples
///
/// ```rust
/// use lib::execute::RUM;
/// use lib::fields::{get, RL};
/// use lib::opcode_matching::{load_value};
///
/// let mut mock_rum = RUM::new(vec![u32::MAX]);
///
/// let instruction = 1_u32;
///
/// load_value(rum, instruction, get(&RL, instruction) as usize);
/// ```
pub fn load_value(rum: &mut RUM, instruction: u32, a: usize) {
    rum.registers[a] = instruction & 0x1FFFFFF;
}
